CarFact — improved UI/UX and structure bundle
Files included:
  - index.html
  - assets/styles.css
  - assets/main.js

What I changed (high level):
  - Cleaner responsive HTML structure and accessible labels.
  - Separated CSS (assets/styles.css) and JS (assets/main.js).
  - Form validation for VIN-like input and mileage.
  - Clear status messages and error handling.
  - Fake API wrapper (fakeApiLookup) — replace with your real backend fetch.
  - Local history saved to localStorage (optional).

How to use:
  1. Replace your repository's index.html and /assets files with these.
  2. If you have a backend API, edit assets/main.js: replace fakeApiLookup(...) with fetch(...) to your endpoint.
  3. Optionally wire up CI to produce a ZIP or GitHub Actions release.

If you want, I can produce a PR patch (diff) instead of a ZIP — provide repo write access or a fork.
